sap.ui.define(['sap/suite/ui/generic/template/lib/AppComponent'], function(AppComponent) {
    return AppComponent.extend('bookshopbooks.Component', {
        metadata: {
            manifest: 'json'
        }
    });
});
